# FitBuddy – AI Fitness Plan Generator

A FastAPI + Jinja2 + SQLite fitness planner based on the supplied project plan. It generates a 7-day workout plan, a nutrition/recovery tip, and revises plans from feedback.

## Gemini model availability + automatic fallback

The original specification names Gemini 1.5 Pro and Gemini Flash. Those model names are not assumed at runtime. FitBuddy uses Google's current `google-genai` SDK and **discovers the models exposed to the configured API key at runtime**.

For workout generation / revisions, the preference chain is:
1. `gemini-3.1-pro-preview`
2. `gemini-3.8-flash`
3. `gemini-3.7-flash`
4. `gemini-3.6-flash`
5. `gemini-3.5-flash`
6. `gemini-2.5-pro`
7. `gemini-2.5-flash`

For fast nutrition/recovery tips:
1. `gemini-3.8-flash`
2. `gemini-3.7-flash`
3. `gemini-3.6-flash`
4. `gemini-3.5-flash`
5. `gemini-3.5-flash-lite`
6. `gemini-3.1-flash-lite`
7. `gemini-2.5-flash`
8. `gemini-2.5-flash-lite`

Before generation, the app calls `client.models.list()` and keeps only available candidates. If a generation attempt fails, it retries with the next candidate and refreshes the model list once. This covers unavailable/deprecated models and transient access changes without requiring code edits.

## Run on Windows

```powershell
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env` and put your Gemini API key in `GEMINI_API_KEY`.

Then:

```powershell
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

Model status: http://127.0.0.1:8000/model-status
FastAPI docs: http://127.0.0.1:8000/docs
Admin: http://127.0.0.1:8000/view-all-users

## Project structure

- `app/main.py` – FastAPI application
- `app/routes.py` – main routes and request handling
- `app/gemini_service.py` – Gemini integration, live discovery and automatic fallback
- `app/database.py` – SQLAlchemy + SQLite persistence
- `app/templates/` – Jinja2 pages
- `app/static/style.css` – responsive UI
- `data/` – runtime SQLite database

## Notes

- Never commit `.env` or a real API key.
- Model availability depends on the API key, project access, quotas and Google's current model lifecycle.
- The model status page is a runtime check, not a guarantee that a model will remain available after the page loads.
- The application provides general fitness information and is not a substitute for individualized medical advice.
