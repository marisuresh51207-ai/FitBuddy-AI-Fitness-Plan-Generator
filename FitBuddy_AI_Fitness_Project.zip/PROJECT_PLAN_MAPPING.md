# Source plan → implementation mapping

This implementation follows the supplied FitBuddy plan: FastAPI backend, Jinja2 templates, SQLite/SQLAlchemy storage, 7-day workout generation, nutrition/recovery tip generation, feedback-based updates, and an admin view.

The supplied document's original Gemini 1.5 Pro / Gemini Flash selection has been modernized to runtime model discovery plus fallback because model availability changes over time.

Routes:
- `/` → user input form
- `/generate-workout` → plan + tip generation and persistence
- `/submit-feedback` → plan revision and persistence
- `/view-all-users` → admin view
- `/delete-user` → admin deletion
- `/model-status` → live Gemini model availability and fallback chains
