"""Gemini service with live model discovery and automatic fallback.

The service never assumes that a preferred model is available. It calls
client.models.list() and selects the first usable model from each role's
preference chain. If a generation call fails because the selected model is
unavailable/rate-limited, it retries with the next discovered candidate.
"""
import os
import logging
from functools import lru_cache
from google import genai
from google.genai import types

log = logging.getLogger(__name__)

WORKOUT_CANDIDATES = [
    'gemini-3.1-pro-preview', 'gemini-3.8-flash', 'gemini-3.7-flash',
    'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-2.5-pro', 'gemini-2.5-flash'
]
FAST_CANDIDATES = [
    'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash',
    'gemini-3.5-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite',
    'gemini-2.5-flash', 'gemini-2.5-flash-lite'
]

class GeminiService:
    def __init__(self):
        api_key = os.getenv('GEMINI_API_KEY') or os.getenv('GOOGLE_API_KEY')
        if not api_key:
            raise RuntimeError('GEMINI_API_KEY is not configured. Copy .env.example to .env and add your key.')
        self.client = genai.Client(api_key=api_key)
        self._models = None

    def discover_models(self, force=False):
        if self._models is not None and not force:
            return self._models
        names = set()
        for model in self.client.models.list():
            name = getattr(model, 'name', '') or ''
            name = name.split('/')[-1]
            if name:
                names.add(name)
        self._models = names
        log.info('Discovered %d Gemini models', len(names))
        return names

    def available_candidates(self, candidates):
        available = self.discover_models()
        return [m for m in candidates if m in available]

    def _generate_with_fallback(self, prompt, candidates, max_output_tokens=5000):
        # First use the live discovery result; then retry discovery once in case availability changed.
        tried = []
        for refresh in (False, True):
            available = self.available_candidates(candidates) if not refresh else [m for m in candidates if m in self.discover_models(force=True)]
            for model in available:
                if model in tried: continue
                tried.append(model)
                try:
                    response = self.client.models.generate_content(
                        model=model,
                        contents=prompt,
                        config=types.GenerateContentConfig(
                            temperature=0.7, max_output_tokens=max_output_tokens
                        )
                    )
                    text = getattr(response, 'text', None)
                    if text: return text, model
                except Exception as exc:
                    log.warning('Gemini model %s failed; trying fallback: %s', model, exc)
                    continue
        raise RuntimeError('No usable Gemini text-generation model is currently available for this API key.')

    def generate_workout(self, username, age, weight, goal, intensity):
        prompt = f"""You are FitBuddy, a fitness-planning assistant. Create a practical 7-day workout plan.
User: {username}; age: {age}; weight: {weight}; goal: {goal}; intensity: {intensity}.
Return clear day-by-day sections. Each day should include focus, warm-up, exercises with sets/reps or duration,
rest guidance, and cooldown/recovery. Include sensible rest/recovery days. Do not diagnose or treat medical conditions.
If a limitation or injury is mentioned, recommend professional guidance rather than prescribing treatment.
Keep the plan readable in plain text and make it suitable for a general adult user.
"""
        return self._generate_with_fallback(prompt, WORKOUT_CANDIDATES)[0]

    def generate_nutrition_tip(self, goal):
        prompt = f"Give one concise, practical nutrition or recovery tip for a general adult whose fitness goal is '{goal}'. Avoid medical claims and extreme dieting."
        return self._generate_with_fallback(prompt, FAST_CANDIDATES, 500)[0]

    def update_workout(self, original_plan, feedback, goal, intensity):
        prompt = f"""Revise this FitBuddy 7-day workout plan based on the user's feedback.
Goal: {goal}; intensity: {intensity}.
Feedback: {feedback}
Original plan:
{original_plan}

Return the complete revised 7-day plan, preserving useful structure while applying the feedback. Keep it general,
safe, and readable. Do not diagnose or treat medical conditions."""
        return self._generate_with_fallback(prompt, WORKOUT_CANDIDATES)[0]

    def status(self):
        models = sorted(self.discover_models())
        return {
            'discovered_count': len(models),
            'discovered_models': models,
            'workout_chain': WORKOUT_CANDIDATES,
            'workout_available': self.available_candidates(WORKOUT_CANDIDATES),
            'fast_chain': FAST_CANDIDATES,
            'fast_available': self.available_candidates(FAST_CANDIDATES),
        }

_service = None

def get_gemini_service():
    global _service
    if _service is None: _service = GeminiService()
    return _service
