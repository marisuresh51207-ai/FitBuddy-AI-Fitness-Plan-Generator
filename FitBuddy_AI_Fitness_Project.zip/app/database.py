import os
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime, timezone

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./data/fitbuddy.db')
connect_args = {'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(100), unique=True, index=True, nullable=False)
    username = Column(String(100), nullable=False)
    age = Column(Integer, nullable=False)
    weight = Column(String(50), nullable=False)
    goal = Column(String(100), nullable=False)
    intensity = Column(String(20), nullable=False)
    original_plan = Column(Text, nullable=False)
    updated_plan = Column(Text, nullable=True)
    nutrition_tip = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

def save_user(data, plan, tip):
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.user_id == data.user_id).first()
        if existing:
            existing.username, existing.age, existing.weight = data.username, data.age, data.weight
            existing.goal, existing.intensity = data.goal, data.intensity
            existing.original_plan, existing.updated_plan, existing.nutrition_tip = plan, None, tip
            db.commit(); db.refresh(existing); return existing
        user = User(user_id=data.user_id, username=data.username, age=data.age, weight=data.weight,
                    goal=data.goal, intensity=data.intensity, original_plan=plan, nutrition_tip=tip)
        db.add(user); db.commit(); db.refresh(user); return user
    finally:
        db.close()

def get_user(user_id):
    db = SessionLocal()
    try: return db.query(User).filter(User.user_id == user_id).first()
    finally: db.close()

def update_plan(user_id, plan, tip=None):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.user_id == user_id).first()
        if not user: return None
        user.updated_plan = plan
        if tip: user.nutrition_tip = tip
        db.commit(); db.refresh(user); return user
    finally: db.close()

def get_all_users():
    db = SessionLocal()
    try: return db.query(User).order_by(User.created_at.desc()).all()
    finally: db.close()

def delete_user(user_id):
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.user_id == user_id).first()
        if user:
            db.delete(user); db.commit(); return True
        return False
    finally: db.close()
