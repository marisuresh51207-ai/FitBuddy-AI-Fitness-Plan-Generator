from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from .database import save_user, get_user, update_plan, get_all_users, delete_user
from .gemini_service import get_gemini_service

router = APIRouter()
templates = Jinja2Templates(directory='app/templates')

class UserInput(BaseModel):
    username: str = Field(min_length=1, max_length=100)
    user_id: str = Field(min_length=1, max_length=100)
    age: int = Field(ge=18, le=100)
    weight: str = Field(min_length=1, max_length=50)
    goal: str = Field(min_length=1, max_length=100)
    intensity: str = Field(pattern='^(low|medium|high)$')

@router.get('/', response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse('index.html', {'request': request})

@router.post('/generate-workout', response_class=HTMLResponse)
def generate_workout(request: Request, username: str = Form(...), user_id: str = Form(...), age: int = Form(...), weight: str = Form(...), goal: str = Form(...), intensity: str = Form(...)):
    try:
        data = UserInput(username=username, user_id=user_id, age=age, weight=weight, goal=goal, intensity=intensity)
        ai = get_gemini_service()
        plan = ai.generate_workout(data.username, data.age, data.weight, data.goal, data.intensity)
        tip = ai.generate_nutrition_tip(data.goal)
        user = save_user(data, plan, tip)
        return templates.TemplateResponse('result.html', {'request': request, 'user': user, 'message': None})
    except Exception as exc:
        return templates.TemplateResponse('error.html', {'request': request, 'error': str(exc)}, status_code=500)

@router.post('/submit-feedback', response_class=HTMLResponse)
def submit_feedback(request: Request, user_id: str = Form(...), feedback: str = Form(...)):
    try:
        user = get_user(user_id)
        if not user: return templates.TemplateResponse('error.html', {'request': request, 'error': 'User ID not found.'}, status_code=404)
        if not feedback.strip(): return templates.TemplateResponse('error.html', {'request': request, 'error': 'Please enter feedback.'}, status_code=400)
        ai = get_gemini_service()
        revised = ai.update_workout(user.original_plan, feedback, user.goal, user.intensity)
        tip = ai.generate_nutrition_tip(user.goal)
        user = update_plan(user_id, revised, tip)
        return templates.TemplateResponse('result.html', {'request': request, 'user': user, 'message': 'Your plan was updated using your feedback.'})
    except Exception as exc:
        return templates.TemplateResponse('error.html', {'request': request, 'error': str(exc)}, status_code=500)

@router.get('/view-all-users', response_class=HTMLResponse)
def view_all_users(request: Request):
    return templates.TemplateResponse('all_users.html', {'request': request, 'users': get_all_users()})

@router.post('/delete-user')
def remove_user(user_id: str = Form(...)):
    delete_user(user_id)
    return RedirectResponse('/view-all-users', status_code=303)

@router.get('/model-status', response_class=HTMLResponse)
def model_status(request: Request):
    try:
        status = get_gemini_service().status()
        return templates.TemplateResponse('model_status.html', {'request': request, 'status': status, 'error': None})
    except Exception as exc:
        return templates.TemplateResponse('model_status.html', {'request': request, 'status': None, 'error': str(exc)}, status_code=500)
